package com.sgcc.nyyy.process.job.aggregation;

import com.sgcc.nyyy.process.config.GlobalProperties;
import com.sgcc.nyyy.process.entity.*;
import com.sgcc.nyyy.process.job.aggregation.sink.RestClientFactoryImpl;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl2;
import com.sgcc.nyyy.process.sink.es.ElasticSinkBuilder;
import com.sgcc.nyyy.process.sink.es.ElasticSinkConfig;
import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.vo.*;
import com.sun.xml.internal.ws.developer.Serialization;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.apache.flink.table.expressions.In;
import org.apache.flink.util.Collector;
import org.elasticsearch.action.ActionRequest;
import scala.Int;
import scala.Unit;

import java.net.MalformedURLException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MinuteUnitPowerAggregation {

    static DeviceAggregationService service = new DeviceAggregationServiceImpl2();


    public void aggregation(SingleOutputStreamOperator<DeviceAggregation> daStream, int windowSize) throws MalformedURLException {

        WindowedStream<FlatDeviceAggregation, Integer, TimeWindow> windowedStream = daStream.flatMap(new FlatMapFunction<DeviceAggregation, FlatDeviceAggregation>() {
            @Override
            public void flatMap(DeviceAggregation deviceAggregation, Collector<FlatDeviceAggregation> collector) throws Exception {

                Set<String> set = new HashSet();
                set.addAll(Arrays.asList(deviceAggregation.getDeviceInUnit()));
                set.addAll(Arrays.asList(deviceAggregation.getStationInUnit()));
                for (String unit : set) {
                    collector.collect(new FlatDeviceAggregation(unit, deviceAggregation.getData()));
                }
            }
        }).keyBy(da -> da.getCode().hashCode() % GlobalProperties.get().getFLINK_TASK_AGGREGATION_SHARD()).window(TumblingEventTimeWindows.of(Time.seconds(windowSize)));

        SingleOutputStreamOperator<ArrayList<UnitPower>> aggregate = windowedStream.aggregate(new AggregateFunction<FlatDeviceAggregation, Map<String, DevicePowerCollector>, ArrayList<FlatDeviceAggregation>>() {

            @Override
            public Map<String, DevicePowerCollector> createAccumulator() {
                return new ConcurrentHashMap<>();
            }

            @Override
            public Map<String, DevicePowerCollector> add(FlatDeviceAggregation flatDeviceAggregation, Map<String, DevicePowerCollector> map) {
                String deviceCode = flatDeviceAggregation.getDevicePower().getCode();
                DevicePowerCollector collector = map.get(deviceCode);

                if (collector == null) {
                    collector = new DevicePowerCollector();
                    map.put(deviceCode, collector);
                    //设置站点code
                    collector.setRelativeCode(flatDeviceAggregation.getCode());
                }
                collector.put(flatDeviceAggregation.getDevicePower());
                return map;
            }

            @Override
            public ArrayList<FlatDeviceAggregation> getResult(Map<String, DevicePowerCollector> map) {
                ArrayList<FlatDeviceAggregation> results = new ArrayList<>();
                for (DevicePowerCollector dc : map.values()) {
                    DevicePower devicePower = dc.aggregation();
                    FlatDeviceAggregation fd = new FlatDeviceAggregation();
                    fd.setCode(dc.getRelativeCode());
                    fd.setDevicePower(devicePower);
                    results.add(fd);

                }
                //返回所有设备数据

                log.error("单元聚合：获取所有设备数据 {}", results);
                return results;
            }

            @Override
            public Map<String, DevicePowerCollector> merge(Map<String, DevicePowerCollector> map1, Map<String, DevicePowerCollector> map2) {
                return AggregationUtil.mergeMap(map1, map2, (c1, c2) -> DevicePowerCollector.merge(c1, c2));
            }
        }).returns(TypeInformation.of(new TypeHint<ArrayList<FlatDeviceAggregation>>() {
        })).map(list -> {


            log.error("单元聚合：开始做数据聚合");
            //获取所有设备id
            ArrayList<String> ids = new ArrayList<>();
            for (FlatDeviceAggregation fd : list) {
                ids.add(fd.getDevicePower().getCode());
            }

            //进行功率单元动态数据汇聚
            Map<String, UnitPower> unitMap = new ConcurrentHashMap<>();

            //将充电桩动态数据合并到功率单元
            if (list.size() > 0) {
                //根据动态数据id批量获取静态数据信息
                Map<String, DeviceInfo> map = service.getDeviceInfoByDeviceIds(ids);

                for (FlatDeviceAggregation fd : list) {

                    DevicePowerData devicePowerData = DevicePowerData.mergeData(fd.getDevicePower(), map.get(fd.getDevicePower().getCode()), DevicePowerData.DATA_TIME_TYPE_ONE);

                    UnitPower unitPower = null;

                    String unitCode = fd.getCode();

                    //为unitPower赋值
                    if (unitMap.containsKey(unitCode)) {
                        unitPower = unitMap.get(unitCode);
                    } else {
                        unitPower = new UnitPower();
                        unitPower.setCode(unitCode);
                        unitMap.put(unitCode, unitPower);
                    }

                    //功率汇总
                    unitPower.setCode(unitCode);

                    //叠加功率数据
                    unitPower.setPower(unitPower.getPower() + fd.getDevicePower().getPower());

                    //叠加额定功率数据
                    unitPower.setRatedPower(unitPower.getRatedPower() + (devicePowerData.getRatedPower() == null ? fd.getDevicePower().getPower() : devicePowerData.getRatedPower().floatValue()));

                    //叠加最小功率数据
                    unitPower.setMinPower(unitPower.getMinPower() + (devicePowerData.getMinPower() == null ? 0 : devicePowerData.getRatedPower().floatValue()));

                    //时间戳
                    unitPower.setTs(Math.max(unitPower.getTs(), fd.getDevicePower().getTs()));

                    //在线设备数
                    unitPower.setOnlineDevice(unitPower.getOnlineDevice() + 1);

                    //设置数据时间类型
                    unitPower.setDataTimeType(UnitPower.DATA_TIME_TYPE_ONE);

                }
            }

            //获取最终聚合单元数据
            ArrayList<UnitPower> result = new ArrayList<>();
            result.addAll(unitMap.values());

            log.error("单元聚合：数据聚合完毕 {}", result);
            return result;
        }).returns(TypeInformation.of(new TypeHint<ArrayList<UnitPower>>() {
        }));

        //存储。
//        aggregate.addSink()

        //数据持久化
        if (GlobalProperties.get().isFLINK_TASK_SINK_ENABLE()) {
            log.error("单元聚合：存储数据库");
            //重试等配置
            ElasticsearchSink<ArrayList<UnitPower>> sink = new ElasticSinkBuilder<>(GlobalProperties.get().getES_LOCAL_HOSTS(), new RestClientFactoryImpl(), handler).build(GlobalProperties.get().getElasticSinkConfig());
            aggregate.addSink(sink);
        }
    }

    private static UnitPowerElasticHandler handler = new UnitPowerElasticHandler();

    @Serialization
    private static class UnitPowerElasticHandler implements ElasticSinkBuilder.ElasticStoreHandler<ArrayList<UnitPower>> {
        @Override
        public String storeIndex(ArrayList<UnitPower> stationPowerData, RuntimeContext runtimeContext) {
//
//            log.error("timestamp:{}", DateUtil.format(runtimeContext.timestamp()));
//            log.error("processingTime:{}", DateUtil.format(runtimeContext.currentProcessingTime()));
//            log.error("watermark:{}", DateUtil.format(runtimeContext.currentWatermark() + 1));
//            log.error("addSink {}", devicePower.toString());
            return "ecp_unit_data";
        }

        @Override
        public void onFailure(ActionRequest actionRequest, Throwable throwable, int restStatusCode, RequestIndexer requestIndexer) {

            log.error(throwable.getMessage());
        }

        @Override
        public boolean onFailureThrowException(Throwable throwable) {
            return false;
        }

    }
}
