package com.sgcc.nyyy.process.job.aggregation;

import com.sgcc.nyyy.process.config.GlobalProperties;
import com.sgcc.nyyy.process.entity.*;
import com.sgcc.nyyy.process.job.aggregation.sink.RestClientFactoryImpl;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl2;
import com.sgcc.nyyy.process.sink.es.ElasticSinkBuilder;
import com.sgcc.nyyy.process.sink.es.ElasticSinkConfig;
import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.vo.DeviceAggregation;
import com.sgcc.nyyy.process.vo.DevicePowerData;
import com.sgcc.nyyy.process.vo.StationPowerData;
import com.sun.xml.internal.ws.developer.Serialization;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.elasticsearch.action.ActionRequest;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
public class MinuteStationPowerAggregation {

    static DeviceAggregationService service = new DeviceAggregationServiceImpl2();

    public void aggregation(SingleOutputStreamOperator<DeviceAggregation> daStream, int windowSize) throws MalformedURLException {

        WindowedStream<FlatDeviceAggregation, Integer, TimeWindow> windowedStream = daStream.map((MapFunction<DeviceAggregation, FlatDeviceAggregation>) deviceAggregation -> {

                    log.error("{}", deviceAggregation);
                    return new FlatDeviceAggregation(deviceAggregation.getStationCode(), deviceAggregation.getData());
                })
                .keyBy(da -> da.getCode().hashCode() % GlobalProperties.get().getFLINK_TASK_AGGREGATION_SHARD()).window(TumblingEventTimeWindows.of(Time.seconds(windowSize)));


        SingleOutputStreamOperator<ArrayList<StationPowerData>> aggregate = windowedStream.aggregate(new AggregateFunction<FlatDeviceAggregation, Map<String, DevicePowerCollector>, ArrayList<FlatDeviceAggregation>>() {

            @Override
            public Map<String, DevicePowerCollector> createAccumulator() {
                return new ConcurrentHashMap<>();
            }

            @Override
            public Map<String, DevicePowerCollector> add(FlatDeviceAggregation flatDeviceAggregation, Map<String, DevicePowerCollector> map) {
                String deviceCode = flatDeviceAggregation.getDevicePower().getCode();
                DevicePowerCollector collector = map.get(deviceCode);

                if (collector == null) {
                    collector = new DevicePowerCollector();
                    map.put(deviceCode, collector);
                    //设置站点code
                    collector.setRelativeCode(flatDeviceAggregation.getCode());
                }
                collector.put(flatDeviceAggregation.getDevicePower());
                return map;
            }

            @Override
            public ArrayList<FlatDeviceAggregation> getResult(Map<String, DevicePowerCollector> map) {
                ArrayList<FlatDeviceAggregation> results = new ArrayList<>();
                for (DevicePowerCollector dc : map.values()) {
                    DevicePower devicePower = dc.aggregation();
                    FlatDeviceAggregation fd = new FlatDeviceAggregation();
                    fd.setCode(dc.getRelativeCode());
                    fd.setDevicePower(devicePower);
                    results.add(fd);

                }
                //返回所有设备数据

                log.error("站点聚合：获取所有设备数据 {}", results.toString());
                return results;
            }

            @Override
            public Map<String, DevicePowerCollector> merge(Map<String, DevicePowerCollector> map1, Map<String, DevicePowerCollector> map2) {
                return AggregationUtil.mergeMap(map1, map2, (c1, c2) -> DevicePowerCollector.merge(c1, c2));
            }
        }).map(list -> {

            log.error("站点聚合：开始做动态数据聚合");
            //进行静态数据获取

            //获取所有设备id
            ArrayList<String> ids = new ArrayList<>();
            for (FlatDeviceAggregation fd : list) {
                ids.add(fd.getDevicePower().getCode());
            }

            //进行站点动态数据汇聚
            Map<String, StationPower> stationMap = new ConcurrentHashMap<>();

            //将充电桩动态数据合并到站点
            if (list.size() > 0) {
                //根据动态数据id批量获取静态数据信息
                Map<String, DeviceInfo> map = service.getDeviceInfoByDeviceIds(ids);

                for (FlatDeviceAggregation fd : list) {

                    DevicePowerData devicePowerData = DevicePowerData.mergeData(fd.getDevicePower(), map.get(fd.getDevicePower().getCode()), DevicePowerData.DATA_TIME_TYPE_ONE);

                    StationPower stationPower = null;

                    String stationCode = fd.getCode();

                    if (stationMap.containsKey(stationCode)) {
                        stationPower = stationMap.get(stationCode);

                    } else {
                        stationPower = new StationPower();
                        stationPower.setCode(stationCode);
                        stationMap.put(stationCode, stationPower);
                    }
                    //功率汇总
                    stationPower.setCode(stationCode);

                    //叠加功率数据
                    stationPower.setPower(stationPower.getPower() + fd.getDevicePower().getPower());

                    //叠加额定功率数据
                    stationPower.setRatedPower(stationPower.getRatedPower() + (devicePowerData.getRatedPower() == null ? fd.getDevicePower().getPower() : devicePowerData.getRatedPower().floatValue()));

                    //叠加最小功率数据
                    stationPower.setMinPower(stationPower.getMinPower() + (devicePowerData.getMinPower() == null ? 0 : devicePowerData.getRatedPower().floatValue()));

                    //时间戳
                    stationPower.setTs(Math.max(stationPower.getTs(), fd.getDevicePower().getTs()));

                    //在线设备数
                    stationPower.setOnlineDevice(stationPower.getOnlineDevice() + 1);

                }
            }

            ArrayList<StationPower> result = new ArrayList<>();
            result.addAll(stationMap.values());

            log.error("站点聚合：聚合动态数据完毕:{}", result);

            return result;
        }).returns(TypeInformation.of(new TypeHint<ArrayList<StationPower>>() {
        })).map(list -> {

            log.error("站点聚合：开始做动静态数据聚合");
            ArrayList<StationPowerData> result = new ArrayList<>();

            //获取所有站点id
            List<String> ids = new ArrayList<>();
            for (StationPower sp : list) {
                ids.add(sp.getCode());
            }

            if (list.size() > 0) {
                //根据动态数据id批量获取静态数据信息
                Map<String, StationInfo> map = service.getStationInfoByStationIds(ids);
                for (StationPower sp : list) {
                    result.add(StationPowerData.mergeData(sp, map.get(sp.getCode()), StationPowerData.DATA_TIME_TYPE_ONE));
                }
            }

            log.error("站点聚合：动静态数据聚合完毕{}", result);
            return result;
        }).returns(TypeInformation.of(new TypeHint<ArrayList<StationPowerData>>() {
        }));

        //数据持久化
        if (GlobalProperties.get().isFLINK_TASK_SINK_ENABLE()) {
            log.error("站点聚合：存储数据库");
            //重试等配置
            ElasticsearchSink<ArrayList<StationPowerData>> sink = new ElasticSinkBuilder<>(GlobalProperties.get().getES_LOCAL_HOSTS(), new RestClientFactoryImpl(), handler).build(GlobalProperties.get().getElasticSinkConfig());
            aggregate.addSink(sink);
        }

    }

    private static StationPowerDataElasticHandler handler = new StationPowerDataElasticHandler();


    @Serialization
    private static class StationPowerDataElasticHandler implements ElasticSinkBuilder.ElasticStoreHandler<ArrayList<StationPowerData>> {
        @Override
        public String storeIndex(ArrayList<StationPowerData> stationPowerData, RuntimeContext runtimeContext) {
//
//            log.error("timestamp:{}", DateUtil.format(runtimeContext.timestamp()));
//            log.error("processingTime:{}", DateUtil.format(runtimeContext.currentProcessingTime()));
//            log.error("watermark:{}", DateUtil.format(runtimeContext.currentWatermark() + 1));
//            log.error("addSink {}", devicePower.toString());
            return "ecp_station_data";
        }

        @Override
        public void onFailure(ActionRequest actionRequest, Throwable throwable, int restStatusCode, RequestIndexer requestIndexer) {

            log.error(throwable.getMessage());
        }

        @Override
        public boolean onFailureThrowException(Throwable throwable) {
            return false;
        }

    }

}

