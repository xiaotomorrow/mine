package com.sgcc.nyyy.process.job.aggregation;

import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.utils.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.*;


@Slf4j
public class MinuteAggregationWatermarkGenerator<T extends MinuteAggregationWatermarkGenerator.AggregationData> implements WatermarkGenerator<T> {

    WatermarkGeneratorSupplier.Context context;


    private long maxOutOfOrderness = 0; // 3.5 秒

    private int windowSize = 60;

    /**
     * @param context
     * @param maxOutOfOrderness 延迟时间
     * @param windowSize        窗口大小，单位秒
     */
    public MinuteAggregationWatermarkGenerator(WatermarkGeneratorSupplier.Context context, long maxOutOfOrderness, int windowSize) {

        this.context = context;
        this.maxOutOfOrderness = maxOutOfOrderness;
        this.windowSize = windowSize;


    }

    /**
     * 每来一条事件数据调用一次，可以检查或者记录事件的时间戳，或者也可以基于事件数据本身去生成 watermark。
     */
    @Override
    public void onEvent(T da, long eventTimestamp, WatermarkOutput output) {


    }


    private long now_watermark = 0l;

    /**
     * 周期性的调用，也许会生成新的 watermark，也许不会。
     *
     * <p>调用此方法生成 watermark 的间隔时间由ExecutionConfig#getAutoWatermarkInterval()} 决定。
     * <p>
     * watermark是一个窗口的【开始时间】在窗口时间结束时，才需要明确该水位线完成（坑了三天多）；
     */
    @Override
    public void onPeriodicEmit(WatermarkOutput output) {

        long timestamp = System.currentTimeMillis() - this.maxOutOfOrderness + 200l;

        long watermark_new = AggregationUtil.getTimestampOfWatermark(timestamp, this.windowSize);

        if (now_watermark < watermark_new) {
            now_watermark = watermark_new;
            log.error("watermark:w{}", DateUtil.format(now_watermark));
        }

        output.emitWatermark(new Watermark(now_watermark));
    }


    public interface AggregationData {

        String dataInfo();

        long eventTime();
    }

}
