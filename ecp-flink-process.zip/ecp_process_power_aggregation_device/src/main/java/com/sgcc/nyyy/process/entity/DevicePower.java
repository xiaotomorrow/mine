package com.sgcc.nyyy.process.entity;

import com.aliyun.openservices.shade.io.netty.util.internal.StringUtil;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class DevicePower {

    //设备编码
    String code;

    //枪编号
    String subCode;

    //功率kw
    float power;

    //时间，将决定该数据属于哪个时间窗口，需要谨慎设置
    long ts;


    //设备静态数据
//    DeviceStaticProperties value;

    public static DevicePower compare(DevicePower d1, DevicePower d2) {

        return d1.ts > d2.ts ? d1 : d2;
    }

    public String getSubCode() {
        if (StringUtil.isNullOrEmpty(subCode))
            subCode = "NONE";
        return subCode;
    }
}
