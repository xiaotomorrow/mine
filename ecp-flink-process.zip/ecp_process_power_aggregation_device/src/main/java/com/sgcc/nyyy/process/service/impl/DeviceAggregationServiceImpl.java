package com.sgcc.nyyy.process.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.sgcc.nyyy.process.entity.*;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.utils.HttpClientHelper;
import com.sgcc.nyyy.process.vo.DeviceAggregation;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;
import java.io.IOException;
import java.util.List;
import java.util.Map;

@Slf4j
@NoArgsConstructor
public class DeviceAggregationServiceImpl implements DeviceAggregationService {


    @Override
    public DeviceAggregation findDeviceAggregationByDevicePower(String deviceCode) {
        DeviceAggregation result = new DeviceAggregation();
        result.setDeviceCode(deviceCode);

        // 查询桩 单元 对应关系
        // status 1代表桩  2代表站
//        List<String> strings = DeviceGroupUtil.getInstance().queryGroupByDeviceID(devicePower.getCode(), 1);
//        result.setDeviceInUnit(strings.toArray(new String[strings.size()]));

        String url ="";
        try {
            String s = HttpClientHelper.sendPost(url);
            JSONObject jsonObject = JSONObject.parseObject(s);
            String data = jsonObject.getString("data");
            result = JSONObject.parseObject(data, DeviceAggregation.class);
        } catch (IOException e) {
            //e.printStackTrace();
            log.error("系统异常",e);
        }
        return result;

    }

    @Override
    public Map<String, DeviceInfo> getDeviceInfoByDeviceIds(List<String> ids) {

        String url ="";
        try {
            String s = HttpClientHelper.sendPost(url);
            JSONObject jsonObject = JSONObject.parseObject(s);
            String data = jsonObject.getString("data");
            Map<String, DeviceInfo> map= JSONObject.parseObject(data, Map.class);
            return map;
        } catch (IOException e) {
            log.error("系统异常",e);
        }
        return null;
    }

    @Override
    public Map<String, StationInfo> getStationInfoByStationIds(List<String> ids) {


        String url ="";
        try {
            String s = HttpClientHelper.sendPost(url);
            JSONObject jsonObject = JSONObject.parseObject(s);
            String data = jsonObject.getString("data");
            Map<String, StationInfo> map= JSONObject.parseObject(data, Map.class);
            return map;
        } catch (IOException e) {
            log.error("系统异常",e);
        }
        return null;
    }


}
