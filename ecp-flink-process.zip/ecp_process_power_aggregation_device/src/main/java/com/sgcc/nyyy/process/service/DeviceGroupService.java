package com.sgcc.nyyy.process.service;

import feign.QueryMap;
import feign.RequestLine;
import java.util.Map;

/**
 * 查询ecp 服务数据
 */
public interface DeviceGroupService {

    @RequestLine("GET /deviceGroup/queryGroupByDeviceID")
    String queryGroupByDeviceID(@QueryMap Map<String, Object> map);

}
