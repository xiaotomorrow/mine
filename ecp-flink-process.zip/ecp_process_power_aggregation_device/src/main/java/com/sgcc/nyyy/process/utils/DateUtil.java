package com.sgcc.nyyy.process.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateUtil {


    public static String format(long ts) {
        SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return fmt.format(new Date(ts));
    }
}
