package com.sgcc.nyyy.process.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class StationInfo {
    //站编码
    String code;

    /**
     * 静态数据
     */
    private String unitCode;

    private Integer stationType; //站类型

    private Integer stationTypeDetail; //站类型明细

    private String provinceCode; //省编号

    private String cityCode; //市编号

    private String districtCode; //区编号
}
