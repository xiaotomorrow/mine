package com.sgcc.nyyy.process.sink.es;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkBase;
import org.apache.flink.util.Preconditions;


@NoArgsConstructor
public class ElasticSinkConfig {

    /**
     * 批量写入时的最大写入条数
     */
    private int bulkFlushMaxActions;
    /**
     * 批量写入时的最大数据量
     */
    private int bulkFlushMaxSizeMb;

    /**
     * 批量写入的时间间隔，
     */
    private long bulkFlushInterval;
    /**
     * 是否重试
     */
    private boolean isBulkFlushBackoff;

    /**
     * 重试策略，有两种：EXPONENTIAL 指数型（表示多次重试之间的时间间隔按照指数方式进行增长）、CONSTANT 常数型（表示多次重试之间的时间间隔为固定常数）
     */
    private ElasticsearchSinkBase.FlushBackoffType flushBackoffType;
    /**
     * 失败重试的次数
     */
    private int bulkFlushBackoffRetries;
    /**
     * 进行重试的时间间隔
     */
    private long bulkFlushBackoffDelay;


    public int getBulkFlushMaxActions() {
        return bulkFlushMaxActions > 0 ? bulkFlushMaxActions : 1;
    }

    public long getBulkFlushInterval() {
        return bulkFlushInterval > 0 ? bulkFlushInterval : 100;
    }

    public int getBulkFlushMaxSizeMb() {
        return bulkFlushMaxSizeMb > 0 ? bulkFlushMaxSizeMb : 2;
    }

    public boolean isBulkFlushBackoff() {
        return isBulkFlushBackoff;
    }

    public ElasticsearchSinkBase.FlushBackoffType getFlushBackoffType() {
        return flushBackoffType;
    }

    public int getBulkFlushBackoffRetries() {
        return bulkFlushBackoffRetries;
    }

    public long getBulkFlushBackoffDelay() {
        return bulkFlushBackoffDelay;
    }


    public void setBulk(long bulkFlushInterval) {
        this.bulkFlushInterval = bulkFlushInterval;
        this.bulkFlushMaxSizeMb = 0;
        this.bulkFlushMaxActions = 0;
    }

    public void setBulk(int bulkFlushMaxActions, int bulkFlushMaxSizeMb) {
        this.bulkFlushInterval = 0;
        this.bulkFlushMaxSizeMb = bulkFlushMaxActions;
        this.bulkFlushMaxActions = bulkFlushMaxSizeMb;
    }

    public void enableBackOff(long delay, int retries) {

        this.isBulkFlushBackoff = true;
        this.bulkFlushBackoffDelay = delay;
        this.bulkFlushBackoffRetries = retries;
        this.flushBackoffType = ElasticsearchSinkBase.FlushBackoffType.CONSTANT;

    }

    public void disableBackOff() {

        this.isBulkFlushBackoff = false;

    }
}
