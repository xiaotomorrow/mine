package com.sgcc.nyyy.process.vo;

import com.alibaba.fastjson.JSONObject;
import com.sgcc.nyyy.process.entity.DeviceInfo;
import com.sgcc.nyyy.process.entity.DevicePower;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.math.BigDecimal;

import static org.apache.calcite.util.DateTimeStringUtils.ISO_DATETIME_FORMAT;

@Slf4j
@Data
@NoArgsConstructor
@ToString
public class DevicePowerData {

    public static final int DATA_TIME_TYPE_ONE = 1;

    public static final int DATA_TIME_TYPE_FIVE = 2;

    public static final int DATA_TIME_TYPE_FIFTEEN = 3;

    public static DevicePowerData mergeData(DevicePower dp, DeviceInfo deviceInfo, int dataTimeType) {

        DevicePowerData devicePowerData = new DevicePowerData();

        devicePowerData.setPileNum(dp.getCode());
        devicePowerData.setDataTimeType(dataTimeType);

        /**
         * 动态数据
         */
        devicePowerData.setPointTime(DateFormatUtils.format(dp.getTs(), ISO_DATETIME_FORMAT));
        devicePowerData.setRealPower(BigDecimal.valueOf(dp.getPower()));

        /**
         * 静态数据
         */
//        devicePowerData.setStationId(deviceInfo.getStationCode());
//        devicePowerData.setRatedPower(deviceInfo.getRatedPower());
//        devicePowerData.setMinPower(deviceInfo.getMinPower());
//        devicePowerData.setMaxPower(deviceInfo.getMaxPower());
//        devicePowerData.setPileType(deviceInfo.getPileType());


        log.info(">>>>>>>>>>>>>>>>>>>>>StationPowerData is :{}", JSONObject.toJSONString(devicePowerData));
        return devicePowerData;
    }


    private String pileNum; //桩编号

    private Integer dataTimeType; //数据类型，1：1分钟 2：5分钟 3：15分钟
    /**
     * 动态数据
     */

    private String pointTime; //时间点位  yyyy/MM/dd HH:mm:ss


    private BigDecimal realPower; //实时功率

    //TODO：电流需要后续处理
    private BigDecimal aCurrent; //电流


    /**
     * 静态数据
     */

    private String stationId; //站编号

    private BigDecimal ratedPower; //额定功率

    private BigDecimal minPower; //可调下线

    private BigDecimal maxPower; //可调下线


    private Integer pileType; //设备类型


}
