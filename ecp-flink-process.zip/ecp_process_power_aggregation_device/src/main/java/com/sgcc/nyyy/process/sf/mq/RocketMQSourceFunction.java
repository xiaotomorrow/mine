package com.sgcc.nyyy.process.sf.mq;

import com.aliyun.openservices.ons.api.*;
import com.aliyun.openservices.ons.api.batch.BatchConsumer;
import com.aliyun.openservices.ons.api.batch.BatchMessageListener;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.List;
import java.util.Properties;

/**
 * @Auther: mei
 * @Date: 2021/02/04/10:58
 * @Description: RocketMQ
 */
@Slf4j
public abstract class RocketMQSourceFunction<T> extends RichSourceFunction<T> {


    private static final long BATCH_PERIOD = 1000l;

    private BatchConsumer consumer;
    private boolean isRunning = false;

    private String group;
    private String accessKey;
    private String secretKey;
    private String address;
    private String topic;
    private String consumerId;
    private String[] tags;


    /**
     * @param group
     * @param accessKey
     * @param secretKey
     * @param address
     * @param topic
     * @param tags
     */
    public RocketMQSourceFunction(String group, String accessKey, String secretKey, String address, String topic, String[] tags, String consumerId) {
        this.group = group;
        this.accessKey = accessKey;
        this.secretKey = secretKey;
        this.address = address;
        this.topic = topic;
        this.tags = tags;
        this.consumerId = consumerId;
    }

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        if (consumer == null) {
            Properties properties = new Properties();
//            properties.put(PropertyKeyConst.GROUP_ID, this.group);
            properties.put(PropertyKeyConst.AccessKey, this.accessKey);
            properties.put(PropertyKeyConst.SecretKey, this.secretKey);
            properties.put(PropertyKeyConst.ONSAddr, this.address);
            properties.put(PropertyKeyConst.ConsumerId, this.consumerId);
            initMQ(properties);
            consumer = ONSFactory.createBatchConsumer(properties);
            //消息数量每次读取的消息数量
        }
    }

    /**
     * @param properties 可以通过properties，对MQ监听类的属性进行进一步的设置。
     */
    protected void initMQ(Properties properties) {
        properties.put(PropertyKeyConst.ConsumeThreadNums, 100);
        properties.put(PropertyKeyConst.ConsumeMessageBatchMaxSize, 1);
    }

    protected abstract T parse(String tag, String message) throws ParseException;


    protected void parseException(String tag, String message, Throwable e) {

        log.error("数据转换失败。tag:{},message:{},errorMessage:{}", tag, message, e.getMessage());

    }


    @Override
    public void run(SourceContext<T> ctx) throws Exception {
        if (!isRunning) {
            //监听消息
            BatchMessageListener messageListener = (messages, context) -> {
                //1、使用JSONObject
                try {
                    for (Message message : messages) {
                        String tag = message.getTag();
                        String s = new String(message.getBody());
                        try {
                            T sendMsg = parse(tag, s);
                            ctx.collect(sendMsg);
                        } catch (Throwable e) {
                            parseException(tag, s, e);
                        }
                    }
                    return Action.CommitMessage;

                } catch (Exception e) {
                    log.error("mq消费异常：", e);
                    return Action.ReconsumeLater;
                }
            };
            consumer.subscribe("nyyy_epc_topic", "", messageListener);
            consumer.start();
            log.info("mq启动成功");
            isRunning = true;
        }
        while (isRunning) {
            Thread.sleep(BATCH_PERIOD);
        }
    }


    private String getAllSubscribeTags() {
        if (tags.length == 0) {
            return "*";
        }
        return String.join("||", tags);
    }

    @Override
    public void close() throws Exception {
        super.close();
        if (consumer != null) {
            consumer.shutdown();
        }
        consumer = null;
        isRunning = false;
    }

    @Override
    public void cancel() {
        if (consumer != null) {
            consumer.shutdown();
        }
        consumer = null;
        isRunning = false;
    }


}
