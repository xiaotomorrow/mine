package com.sgcc.nyyy.process.utils;

import com.alibaba.fastjson.JSONObject;
import com.sgcc.nyyy.process.config.GlobalProperties;
import com.sgcc.nyyy.process.service.DeviceGroupService;
import com.sgcc.nyyy.process.vo.BaseResponse;
import com.sgcc.nyyy.process.vo.DeviceGroupVO;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.compress.utils.Lists;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DeviceGroupUtil {

    private static volatile DeviceGroupUtil instance = null;
    /**
     * 初始化
     * 单例模式
     * @return
     */
    public static DeviceGroupUtil getInstance() {
        if (instance == null) {
            synchronized (instance) {
                instance = new DeviceGroupUtil();
            }
        }
        return instance;
    }

    /**
     * 查询ecp 服务数据
     * @param assetId
     * @param status
     * @return
     */
    public  List<String> queryGroupByDeviceID (String assetId, Integer status) {
        List<String> resultList = Lists.newArrayList();

        //客户端调用
        Map<String, Object> map = new HashMap<>();
        map.put("assetId", assetId);
        map.put("status", status);
        DeviceGroupService deviceGroupService = FeignUtils.getInstance()
                .target(DeviceGroupService.class, GlobalProperties.get().getECP_RESOURCE_ADDRESS());
        String result = deviceGroupService.queryGroupByDeviceID(map);
        BaseResponse<List<DeviceGroupVO>> deviceVO = JSONObject.parseObject(result,BaseResponse.class);
        if (deviceVO.getResultCode() == 200) {
            List<DeviceGroupVO> deviceVOData = deviceVO.getData();
            log.info(">>>>>>>>>>>>>>>>>>>>>> result is :" + deviceVOData);
            for (DeviceGroupVO temp : deviceVOData) {
                resultList.add(temp.getUnitId());
            }
        }
        return resultList;
    }

}
