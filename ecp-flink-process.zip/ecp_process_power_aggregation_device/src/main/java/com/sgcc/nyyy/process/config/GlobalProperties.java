package com.sgcc.nyyy.process.config;

import com.sgcc.nyyy.process.sink.es.ElasticSinkConfig;
import com.sgcc.nyyy.process.utils.PropertyConfig;
import lombok.Getter;

import java.io.IOException;

@Getter
public class GlobalProperties extends PropertyConfig {

    private static GlobalProperties properties;

    static {
        try {
            properties = new GlobalProperties();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static GlobalProperties get() {
        return properties;
    }

    private static final String PROP_GROUP_ID = "ali.MQ.GROUP_ID";
    private static final String PROP_MQ_AccessKey = "ali.MQ.AccessKey";
    private static final String PROP_MQ_SecretKey = "ali.MQ.SecretKey";
    private static final String PROP_MQ_ONSAddr = "ali.MQ.ONSAddr";

    private static final String PROP_TOPIC_MINUTE_AGGREATION = "TOPIC_MINUTE_AGGREATION";
    private static final String PROP_TAG_DEVICE_NEW = "TAG_DEVICE_NEW";
    private static final String PROP_TAG_DEVICE_HISTORY = "TAG_DEVICE_HISTORY";
    private static final String CONSUMER_ID = "CONSUMER_ID";

    private String MQ_GROUP_ID;

    private String MQ_AccessKey;

    private String MQ_SecretKey;

    private String MQ_ONSAddr;

    private String TOPIC_MINUTE_AGGREATION;

    private String TAG_DEVICE_NEW;

    private String TAG_DEVICE_HISTORY;

    private ElasticSinkConfig elasticSinkConfig;

    private String CONSUMERID;

    //--------------------ES 配置信息 ----------------------------
    // device索引名称
    private static final String PROP_ES_DEVICE_INDEX = "es.device.index";
    // station索引名称
    private static final String PROP_ES_STATION_INDEX = "es.station.index";
    // unit索引名称
    private static final String PROP_ES_UNIT_INDEX = "es.unit.index";

    // bulkFlushMaxActions
    private static final String PROP_ES_BULK_FLUSH_MAX_ACTIONS = "es.bulkFlushMaxActions";
    // bulkFlushInterval
    private static final String PROP_ES_BULK_FLUSH_INTERVAL = "es.bulkFlushInterval";
    // bulkFlushMaxSizeMb
    private static final String PROP_ES_BULK_FLUSH_MAX_SIZE_MB = "es.bulkFlushMaxSizeMb";
    // isBulkFlushBackoff
    private static final String PROP_ES_BULK_FLUSH_BACKOFF = "es.isBulkFlushBackoff";
    // bulkFlushBackoffRetries
    private static final String PROP_ES_BULK_FLUSH_BACKOFF_RETRIES = "es.bulkFlushBackoffRetries";
    // bulkFlushBackoffDelay
    private static final String PROP_ES_BULK_FLUSH_BACKOFF_DELAY = "es.bulkFlushBackoffDelay";

    private String ES_LOCAL_HOSTS;

    private String ES_USER;

    private String ES_PASSWORD;

    private String ES_DEVICE_INDEX;

    private String ES_STATION_INDEX;

    private String ES_UNIT_INDEX;


    //--------------------ES 配置信息 END----------------------------


    //--------------------ECP RESOURCE 配置信息 START----------------------------

    private static final String PROP_ECP_RESOURCE_ADDRESS = "ecp.resource.address";

    private static final String PROP_ECP_CONNECT_TIMEOUT_MILLIS = "ecp.http.connect.timeout.millis";

    private static final String PROP_ECP_READ_TIMEOUT_MILLIS = "ecp.http.read.timeout.millis";

    private String ECP_RESOURCE_ADDRESS;

    private int ECP_CONNECT_TIMEOUT_MILLIS;

    private int ECP_READ_TIMEOUT_MILLIS;
    //--------------------ECP RESOURCE 配置信息 END----------------------------


    //--------------------FLINK 任务配置 配置信息 START----------------------------


    private static final String PROP_FLINK_TASK_AGGREGATION_SHARD = "flink.task.aggregation.shard";
    private static final String PROP_FLINK_TASK_SINK_ENABLE = "flink.task.sink.enable";


    private int FLINK_TASK_AGGREGATION_SHARD;
    private boolean FLINK_TASK_SINK_ENABLE;

    //--------------------FLINK 任务配置 配置信息 END----------------------------
    public GlobalProperties() throws IOException {
        super("application.properties");

        this.MQ_GROUP_ID = getString(PROP_GROUP_ID);
        this.MQ_AccessKey = getString(PROP_MQ_AccessKey);
        this.MQ_SecretKey = getString(PROP_MQ_SecretKey);
        this.MQ_ONSAddr = getString(PROP_MQ_ONSAddr);
        this.TOPIC_MINUTE_AGGREATION = getString(PROP_TOPIC_MINUTE_AGGREATION);
        this.TAG_DEVICE_NEW = getString(PROP_TAG_DEVICE_NEW);
        this.TAG_DEVICE_HISTORY = getString(PROP_TAG_DEVICE_HISTORY);
        this.CONSUMERID = getString(CONSUMER_ID);
        this.ES_LOCAL_HOSTS = getString("es.cluster.address.local");
        this.ES_USER = getString("es.username");
        this.ES_PASSWORD = getString("es.password");
        this.ECP_RESOURCE_ADDRESS = getString(PROP_ECP_RESOURCE_ADDRESS);
        this.ES_DEVICE_INDEX = getString(PROP_ES_DEVICE_INDEX);
        this.ES_STATION_INDEX = getString(PROP_ES_STATION_INDEX);
        this.ES_UNIT_INDEX = getString(PROP_ES_UNIT_INDEX);
        this.ECP_CONNECT_TIMEOUT_MILLIS = getInt(PROP_ECP_CONNECT_TIMEOUT_MILLIS);
        this.ECP_READ_TIMEOUT_MILLIS = getInt(PROP_ECP_READ_TIMEOUT_MILLIS);
        this.FLINK_TASK_AGGREGATION_SHARD = getInt(PROP_FLINK_TASK_AGGREGATION_SHARD);
        this.FLINK_TASK_SINK_ENABLE = getBoolean(PROP_FLINK_TASK_SINK_ENABLE);
        initSinkConfig();

    }

    private void initSinkConfig() {
        this.elasticSinkConfig = new ElasticSinkConfig();
        this.elasticSinkConfig.setBulk(getInt(PROP_ES_BULK_FLUSH_INTERVAL));
        this.elasticSinkConfig.enableBackOff(getInt(PROP_ES_BULK_FLUSH_BACKOFF_DELAY), getInt(PROP_ES_BULK_FLUSH_BACKOFF_RETRIES));
    }


}
