package com.sgcc.nyyy.process.vo;

import com.alibaba.fastjson.JSONObject;
import com.sgcc.nyyy.process.entity.DeviceInfo;
import com.sgcc.nyyy.process.entity.DevicePower;
import com.sgcc.nyyy.process.entity.StationInfo;
import com.sgcc.nyyy.process.entity.StationPower;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateFormatUtils;

import java.math.BigDecimal;

import static org.apache.calcite.util.DateTimeStringUtils.ISO_DATETIME_FORMAT;

@Slf4j
@NoArgsConstructor
@ToString
@Data
public class StationPowerData {


    public static final int DATA_TIME_TYPE_ONE = 1;

    public static final int DATA_TIME_TYPE_FIVE = 2;

    public static final int DATA_TIME_TYPE_FIFTEEN = 3;

    public static StationPowerData mergeData(StationPower dp, StationInfo stationInfo, int dataTimeType) {
        StationPowerData stationPowerData = new StationPowerData();
        stationPowerData.setStationId(stationInfo.getCode());
        stationPowerData.setDataTimeType(dataTimeType);

        //设备动态数据，从StationPower中获取
        stationPowerData.setRealPower(BigDecimal.valueOf(dp.getPower()));
        stationPowerData.setPointTime(DateFormatUtils.format(dp.getTs(), ISO_DATETIME_FORMAT));
        stationPowerData.setOnlineCount(dp.getOnlineDevice());
        stationPowerData.setRatedPower(BigDecimal.valueOf(dp.getRatedPower()));
        stationPowerData.setMinPower(BigDecimal.valueOf(dp.getMinPower()));
        stationPowerData.setMaxPower(BigDecimal.valueOf(dp.getRatedPower()));

        //设备静态数据，StationInfo
        stationPowerData.setStationType(stationInfo.getStationType());
        stationPowerData.setStationTypeDetail(stationInfo.getStationTypeDetail());
        stationPowerData.setProvinceCode(stationInfo.getProvinceCode());
        stationPowerData.setCityCode(stationInfo.getCityCode());
        stationPowerData.setDistrictCode(stationInfo.getDistrictCode());
        log.info(">>>>>>>>>>>>>>>>>>>>>StationPowerData is :{}", JSONObject.toJSONString(stationPowerData));
        return stationPowerData;
    }

    private String stationId; //站编号

    private Integer dataTimeType; //数据类型，1：1分钟 2：5分钟 3：15分钟

    /**
     * 动态数据
     */
    private String pointTime; //时间点位  yyyy/MM/dd HH:mm:ss

    private BigDecimal realPower; //功率

    private Integer onlineCount; //在线设备数

    private BigDecimal ratedPower; //额定功率

    private BigDecimal minPower; //最小功率

    private BigDecimal maxPower; //最大功率


    /**
     * 静态数据
     */
    //TODO：如何解决聚合单元问题
    private Integer unitId; //聚合单元问题

    private String platformId; //运营商

    private Integer stationType; //站类型

    private Integer stationTypeDetail; //站类型明细

    private String provinceCode; //省编号

    private String cityCode; //市编号

    private String districtCode; //区编号

}
