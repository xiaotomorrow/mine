package com.sgcc.nyyy.process.sink.es;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.apache.calcite.tools.Hoist;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkBase;
import org.apache.flink.streaming.connectors.elasticsearch7.RestClientFactory;
import org.apache.http.HttpHost;

import java.util.List;


@Data
@AllArgsConstructor
public class ElasticSinkNetworkConfig {

    List<HttpHost> httpHosts;

    RestClientFactory restClientFactory;


}
