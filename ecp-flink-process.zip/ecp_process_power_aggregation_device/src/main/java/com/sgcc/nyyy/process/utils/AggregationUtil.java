package com.sgcc.nyyy.process.utils;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;

@Slf4j
public class AggregationUtil {


    /**
     * @param timestamp  确定归属哪个分钟级时间窗口,向上取整
     * @param windowSize 窗口大小，单位秒
     * @return
     */
    public synchronized static long getTimestampOfWatermark(long timestamp, int windowSize) {
        BigDecimal bigDecimal = new BigDecimal(timestamp);
        double t = bigDecimal.divide(BigDecimal.valueOf(1000 * windowSize), BigDecimal.ROUND_DOWN).doubleValue();
        return (long) (t * windowSize * 1000l);
    }

    /**
     * @param timestamp  确定归属哪个分钟级时间窗口,向上取整
     * @param windowSize 窗口大小，单位秒
     * @return
     */
    public synchronized static long getDevicestampOfWatermark(long timestamp, int windowSize) {
        BigDecimal bigDecimal = new BigDecimal(timestamp);
        double t = bigDecimal.divide(BigDecimal.valueOf(1000 * windowSize), BigDecimal.ROUND_UP).doubleValue();
        return (long) (t * windowSize * 1000l);
    }


    public static void main(String[] args) {

        SimpleDateFormat fmt = new SimpleDateFormat("MM:dd HH:mm:ss");
        long timestamp = 1639135234218l;
//        System.out.println(Math.ceil((double) (timestamp / 1000l / 10)));
//        System.out.println(fmt.format(new Date(timestamp)));
//        System.out.println(fmt.format(new Date(getTimestampMinuteWatermark(timestamp))));
        System.out.println(fmt.format(new Date(getTimestampOfWatermark(timestamp, 15))));

    }

    public static <K, V> Map<K, V> mergeMap(Map<K, V> acc1, Map<K, V> acc2, BiFunction<V, V, V> func) {
        Map<K, V> map = new ConcurrentHashMap<>();
        map.putAll(acc1);
        for (K key : acc2.keySet()) {

            V value2 = acc2.get(key);

            if (map.containsKey(key)) {
                V value1 = map.get(key);
                map.put(key, func.apply(value1, value2));
            } else {
                map.put(key, value2);
            }
        }
        return map;
    }


    /**
     * @param time       当前时间
     * @param windowsize 窗口时间
     * @param delay      可接受延迟
     * @return 当前时间是否不可纳入窗口
     */
    public static boolean isOutDated(long time, int windowsize, long delay) {

        long watermark_timestamp = System.currentTimeMillis() - delay;
        long time_min = getTimestampOfWatermark(watermark_timestamp, windowsize);//获取当前时间所接纳水位（上限）
        long time_max = getTimestampOfWatermark(System.currentTimeMillis(), windowsize) + windowsize * 1000;//获取当前时间所在水位（上限）
        return !(time >= time_min && time <= time_max);
    }

}