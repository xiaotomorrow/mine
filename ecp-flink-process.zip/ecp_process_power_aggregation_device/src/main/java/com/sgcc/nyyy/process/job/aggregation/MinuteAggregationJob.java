package com.sgcc.nyyy.process.job.aggregation;

import com.aliyun.openservices.shade.com.alibaba.fastjson.JSON;
import com.aliyun.openservices.shade.com.alibaba.fastjson.JSONObject;
import com.sgcc.nyyy.process.config.GlobalProperties;
import com.sgcc.nyyy.process.job.BaseFlinkJob;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl2;
import com.sgcc.nyyy.process.sf.mq.RocketMQSourceFunction;
import com.sgcc.nyyy.process.sf.simulate.SimulateSourceFunction;
import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.utils.DateUtil;
import com.sgcc.nyyy.process.vo.DeviceAggregation;
import com.sgcc.nyyy.process.entity.DevicePower;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkGenerator;
import org.apache.flink.api.common.eventtime.WatermarkGeneratorSupplier;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;
import org.apache.flink.streaming.api.functions.timestamps.BoundedOutOfOrdernessTimestampExtractor;
import org.apache.flink.streaming.api.windowing.time.Time;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.MalformedURLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.Date;
import java.util.Random;

@Slf4j
public class MinuteAggregationJob extends BaseFlinkJob<DevicePower> {

    private static final String name = "ecp-process-device-minute-aggregation-job";

    private static GlobalProperties properties;

    private static final int windowSize = 20;

    private static final int lagTime = 3000;

    //静态变量或者序列化
    private static DeviceAggregationService deviceAggregationService = new DeviceAggregationServiceImpl2();


    static {
        try {
            properties = new GlobalProperties();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public MinuteAggregationJob() {
        super(name);
    }

    @Override
    protected void initEnvironment(StreamExecutionEnvironment env) {
        super.initEnvironment(env);
        //TODO:环境的配置
    }


    @Override
    protected SourceFunction<DevicePower> getSourceFunction() {
//        return new MQSourceFunction();
        //测试数据

//        int threadNumber = 5;
//        long interval = 1000l;
//        log.error("开始模拟数据源,线程数:{}，周期：{}ms", threadNumber, interval);
        return new MySimulateSourceFunction(5, 100000l);
    }

    private static MinuteAggregationWatermarkGenerator gen;

    static synchronized MinuteAggregationWatermarkGenerator getMinuteAggregationWatermarkGenerator(WatermarkGeneratorSupplier.Context context) {
        if (gen == null) {
            gen = new MinuteAggregationWatermarkGenerator(context, lagTime, windowSize);
        }
        gen.context = context;

        return gen;

    }


    static WatermarkGeneratorSupplier<DeviceAggregation> watermarkGeneratorSupplier = new WatermarkGeneratorSupplier<DeviceAggregation>() {
        @Override
        public WatermarkGenerator<DeviceAggregation> createWatermarkGenerator(Context context) {
            return getMinuteAggregationWatermarkGenerator(context);
        }
    };


    @Override
    protected boolean process(DataStream<DevicePower> ds) {


        log.error("开始启动整合窗口:{}sec，延迟：{}ms", windowSize, lagTime);

        SingleOutputStreamOperator<DeviceAggregation> daStream = ds.map(devicePower -> {

            //通过数据源获取报文信息，并查询报文的聚合信息
//            DeviceAggregation da = deviceAggregationService.findDeviceAggregationByDevicePower(devicePower.getCode());
            DeviceAggregation da = new DeviceAggregation();
            da.setDeviceCode(devicePower.getCode());
            da.setData(devicePower);
            return da;
        }).assignTimestampsAndWatermarks(WatermarkStrategy.<DeviceAggregation>forGenerator(watermarkGeneratorSupplier).withTimestampAssigner(new SerializableTimestampAssigner<DeviceAggregation>() {
            @Override
            public long extractTimestamp(DeviceAggregation da, long l) {
                //编辑数据实际时间戳，采用EventTime模式
                return da.getData().getTs();
            }
        }));
        //完成1分钟设备汇聚
        try {

            processDeviceMiniute(daStream);
            //完成1分钟站点汇聚
//            processStationMiniute(daStream);
            //完成1分钟聚合单元汇聚
//            processUnitMiniute(daStream);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            log.error("启动汇聚失败", e);
            return false;
        }

    }


    /**
     * 处理设备的分钟级数据
     */
    private void processDeviceMiniute(SingleOutputStreamOperator<DeviceAggregation> daStream) throws IOException {

        //分钟级数据和在MinuteDevicePowerAggregation实现
        MinuteDevicePowerAggregation aggregation = new MinuteDevicePowerAggregation();
        aggregation.aggregation(daStream, windowSize, lagTime);
    }

    /**
     * 处理站点的分钟级数据
     */
    private void processStationMiniute(SingleOutputStreamOperator<DeviceAggregation> daStream) throws IOException {

        log.error("启动数据设备聚合");
        //分钟级数据和在MinuteStationPowerAggregation实现
        MinuteStationPowerAggregation aggregation = new MinuteStationPowerAggregation();
        aggregation.aggregation(daStream, windowSize);

    }

    /**
     * 处理聚合单元的分钟级数据
     */
    private void processUnitMiniute(SingleOutputStreamOperator<DeviceAggregation> daStream) throws IOException {

        log.error("启动聚合单元聚合");
        //分钟级数据和在MinuteUnitPowerAggregation实现
        MinuteUnitPowerAggregation aggregation = new MinuteUnitPowerAggregation();
        aggregation.aggregation(daStream, windowSize);
    }


    /**
     * MQ资源，用来监控消息后，生成DataStream，这里要监测所有的消息
     */
    private static class MQSourceFunction extends RocketMQSourceFunction<DevicePower> {


        public MQSourceFunction() {
            super(properties.getMQ_GROUP_ID(), properties.getMQ_AccessKey(),
                    properties.getMQ_SecretKey(), properties.getMQ_ONSAddr(),
                    properties.getTOPIC_MINUTE_AGGREATION(), new String[]{properties.getTAG_DEVICE_NEW(), properties.getTAG_DEVICE_HISTORY()}, properties.getCONSUMERID());
        }

        @Override
        protected DevicePower parse(String tag, String message) throws ParseException {
            JSONObject jsonObject = JSON.parseObject(message);
            SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
            String pileNum = jsonObject.getString("pileNum");
            String multiPileNum = jsonObject.getString("multiPileNum");
            String fesSampTime = jsonObject.getString("fesSampTime");
            BigDecimal realPower = jsonObject.getBigDecimal("realPower");
            BigDecimal aCurrent = jsonObject.getBigDecimal("aCurrent");
            DevicePower devicePower = new DevicePower();
            devicePower.setCode(pileNum);
            devicePower.setSubCode(multiPileNum);
            devicePower.setPower(realPower.floatValue());
            devicePower.setTs(format.parse(fesSampTime).getTime());
            //将设备报文数据转化为DevicePower报文数据
            System.out.println("收到报文" + message);
            return devicePower;
        }
    }


    /**
     * 模拟MQ发出 报文数据
     */
    private static class MySimulateSourceFunction extends SimulateSourceFunction<DevicePower> {

        Random random = new Random();

        public MySimulateSourceFunction(int threadNumber, long interval) {
            super(threadNumber, interval);
        }

        @Override
        protected DevicePower simulate() {

            DevicePower dp = new DevicePower();
            dp.setCode("device_" + random.nextInt(3));
            dp.setPower(1.0f);
            long timestamp = System.currentTimeMillis() - (random.nextInt(30) - 15) * 1000;
            log.error("设备 :{} timestamp :{}  模拟时间 :{}  所属窗口 :w{}", dp.getCode(), timestamp, DateUtil.format(timestamp), DateUtil.format(AggregationUtil.getDevicestampOfWatermark(timestamp, windowSize)));
            dp.setTs(timestamp);
            return dp;
        }
    }

}
