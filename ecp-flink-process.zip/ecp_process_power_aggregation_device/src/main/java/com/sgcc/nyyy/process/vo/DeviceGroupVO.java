package com.sgcc.nyyy.process.vo;

import lombok.Data;

import java.io.Serializable;

@Data
public class DeviceGroupVO implements Serializable {

    /**
     * 桩编号
     */
    private String assetId;

    /**
     * 桩集群id
     */
    private String unitId;

    public DeviceGroupVO(String assetId, String unitId) {
        this.assetId = assetId;
        this.unitId = unitId;
    }

    public DeviceGroupVO() {
    }

}
