package com.sgcc.nyyy.process.vo;


import com.sgcc.nyyy.process.entity.DevicePower;
import com.sgcc.nyyy.process.job.aggregation.MinuteAggregationWatermarkGenerator;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
public class DeviceAggregation implements MinuteAggregationWatermarkGenerator.AggregationData {

    //设备Code
    String deviceCode;

    //设备报文数据
    DevicePower data;

    //设备的聚合单元信息
    String[] deviceInUnit;

    //设备的站点信息
    String stationCode;

    //设备的站点聚合单元信息
    String[] stationInUnit;


    @Override
    public String dataInfo() {
        return toString();
    }

    @Override
    public long eventTime() {
        return data.getTs();
    }
}
