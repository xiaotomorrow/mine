package com.sgcc.nyyy.process.entity;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class FlatDeviceAggregation {

    //编码
    String code;

    //桩
    DevicePower devicePower;
}
