package com.sgcc.nyyy.process.service.impl;

import com.sgcc.nyyy.process.entity.*;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.vo.DeviceAggregation;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class DeviceAggregationServiceImpl2 implements DeviceAggregationService {


    HashMap<String, DeviceAggregation> map = new HashMap<>();


    HashMap<String, DeviceInfo> deviceInfoMap = new HashMap<>();


    HashMap<String, StationInfo> stationInfoHashMap = new HashMap<>();

    public DeviceAggregationServiceImpl2() {
        //station_012,station_3,station_4
        //unit_station_012_3,unit_station_3_4,unit_station_012_4
        //unit_device_123,unit_device_134,unit_device_034,unit_device_02
        DeviceAggregation device_0 = new DeviceAggregation();
        device_0.setDeviceCode("device_0");
        device_0.setStationCode("station_012");
        device_0.setDeviceInUnit(new String[]{"unit_device_034", "unit_device_02"});
        device_0.setStationInUnit(new String[]{"unit_station_012_3", "unit_station_012_4"});


        DeviceAggregation device_1 = new DeviceAggregation();
        device_1.setDeviceCode("device_1");
        device_1.setStationCode("station_012");
        device_1.setDeviceInUnit(new String[]{"unit_device_123", "unit_device_134"});
        device_1.setStationInUnit(new String[]{"unit_station_012_3", "unit_station_012_4"});

        DeviceAggregation device_2 = new DeviceAggregation();
        device_2.setDeviceCode("device_2");
        device_2.setStationCode("station_012");
        device_2.setDeviceInUnit(new String[]{"unit_device_02", "unit_device_123"});
        device_2.setStationInUnit(new String[]{"unit_station_012_3", "unit_station_012_4"});

        DeviceAggregation device_3 = new DeviceAggregation();
        device_3.setDeviceCode("device_3");
        device_3.setStationCode("station_3");
        device_3.setDeviceInUnit(new String[]{"unit_device_123", "unit_device_134", "unit_device_034"});
        device_3.setStationInUnit(new String[]{"unit_station_012_3", "unit_station_3_4"});

        DeviceAggregation device_4 = new DeviceAggregation();
        device_4.setDeviceCode("device_4");
        device_4.setStationCode("station_4");
        device_4.setDeviceInUnit(new String[]{"unit_device_134", "unit_device_034"});
        device_4.setStationInUnit(new String[]{"unit_station_012_4", "unit_station_3_4"});


        map.put("device_0", device_0);

        map.put("device_1", device_1);

        map.put("device_2", device_2);

        map.put("device_3", device_3);

        map.put("device_4", device_4);

//        station_012,station_3,station_4
        DeviceInfo deviceInfo_0 = new DeviceInfo("device_0", "station_012", BigDecimal.valueOf(7), BigDecimal.valueOf(0), BigDecimal.valueOf(7), 1);

        DeviceInfo deviceInfo_1 = new DeviceInfo("device_1", "station_012", BigDecimal.valueOf(30), BigDecimal.valueOf(1.4), BigDecimal.valueOf(30), 2);

        DeviceInfo deviceInfo_2 = new DeviceInfo("device_2", "station_012", BigDecimal.valueOf(7), BigDecimal.valueOf(1.4), BigDecimal.valueOf(7), 1);

        DeviceInfo deviceInfo_3 = new DeviceInfo("device_3", "station_3", BigDecimal.valueOf(60), BigDecimal.valueOf(1.4), BigDecimal.valueOf(60), 3);

        DeviceInfo deviceInfo_4 = new DeviceInfo("device_4", "station_4", BigDecimal.valueOf(100), BigDecimal.valueOf(1.4), BigDecimal.valueOf(100), 3);


        deviceInfoMap.put("device_0", deviceInfo_0);
        deviceInfoMap.put("device_1", deviceInfo_1);
        deviceInfoMap.put("device_2", deviceInfo_2);
        deviceInfoMap.put("device_3", deviceInfo_3);
        deviceInfoMap.put("device_4", deviceInfo_4);

        // station_012, station_3, station_4
        //
        //unit_station_012_3,unit_station_3_4,unit_station_012_4

        StationInfo stationInfo_012 = new StationInfo("station_012", "unit_station_012_3", 1, 1, "1100000", "1122000", "1122333");

        StationInfo stationInfo_3 = new StationInfo("station_3", "unit_station_3_4", 2, 2, "2200000", "2222000", "2222333");

        StationInfo stationInfo_4 = new StationInfo("station_4", "unit_station_012_4", 1, 2, "1100000", "1122000", "1122333");

        stationInfoHashMap.put("station_012", stationInfo_012);

        stationInfoHashMap.put("station_3", stationInfo_3);

        stationInfoHashMap.put("station_4", stationInfo_4);


    }

    @Override
    public DeviceAggregation findDeviceAggregationByDevicePower(String deviceCode) {
        DeviceAggregation da = map.get(deviceCode);
        return da;
    }

    @Override
    public Map<String, DeviceInfo> getDeviceInfoByDeviceIds(List<String> ids) {

        Map<String, DeviceInfo> map = new HashMap<>();
        for (String id : ids) {

            map.put(id, deviceInfoMap.get(id));
        }
        return map;
    }

    @Override
    public Map<String, StationInfo> getStationInfoByStationIds(List<String> ids) {

        Map<String, StationInfo> map = new HashMap<>();
        for (String id : ids) {

            map.put(id, stationInfoHashMap.get(id));
        }
        return map;
    }


}
