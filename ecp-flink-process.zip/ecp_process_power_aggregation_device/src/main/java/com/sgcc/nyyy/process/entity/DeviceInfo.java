package com.sgcc.nyyy.process.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;

@Data
@NoArgsConstructor
@ToString
@AllArgsConstructor
public class DeviceInfo {

    private String code; //桩编号
    /**
     * 静态数据
     */
    private String stationCode;

    private BigDecimal ratedPower; //额定功率

    private BigDecimal minPower; //可调下线

    private BigDecimal maxPower; //可调下线

    private Integer pileType; //设备类型


}
