package com.sgcc.nyyy.process.service;

import com.sgcc.nyyy.process.entity.*;
import com.sgcc.nyyy.process.vo.DeviceAggregation;

import java.util.List;
import java.util.Map;


public interface DeviceAggregationService {


    /**
     * 根据设备报文信息获取设备聚合信息，
     *
     * @param deviceCode
     * @return
     */
    DeviceAggregation findDeviceAggregationByDevicePower(String deviceCode);

    Map<String, DeviceInfo> getDeviceInfoByDeviceIds(List<String> ids);

    Map<String, StationInfo> getStationInfoByStationIds(List<String> ids);


}
