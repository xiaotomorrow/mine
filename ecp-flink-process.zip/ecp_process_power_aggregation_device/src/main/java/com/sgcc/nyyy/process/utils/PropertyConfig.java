package com.sgcc.nyyy.process.utils;


import lombok.extern.slf4j.Slf4j;

import java.io.IOException;
import java.io.Serializable;
import java.util.Properties;

/**
 * @Auther: mei
 * @Date: 2021/02/02/16:51
 * @Description: 配置文件加载
 */
@Slf4j
public class PropertyConfig implements Serializable {

    private Properties properties;

    public PropertyConfig(String filePath) throws IOException {
        this.properties = new Properties();
        try {
            properties.load(this.getClass().getClassLoader().getResourceAsStream(filePath.trim()));
        } catch (IOException e) {
            log.error("加载配置文件出错 {}", e);
            throw e;
        }
    }

    public String getString(String key) {
        return this.properties.getProperty(key).trim();
    }

    public String getAsciiString(String key) {
        return this.properties.getProperty(key);
    }

    public String getString(String key, String defaultValue) {
        return this.properties.getProperty(key, defaultValue).trim();
    }

    public int getInt(String key) {
        String value = this.properties.getProperty(key);
        return Integer.parseInt(value.trim());
    }

    public int getInt(String key, Integer defaultValue) {
        String value = this.properties.getProperty(key);
        return value != null ? Integer.parseInt(value.trim()) : defaultValue;
    }

    public boolean getBoolean(String key) {
        return Boolean.parseBoolean(this.properties.getProperty(key));
    }

    public Boolean getBoolean(String key, Boolean defaultValue) {
        String value = this.properties.getProperty(key);
        return value != null ? Boolean.valueOf(Boolean.parseBoolean(value.trim())) : defaultValue;
    }

    public float getFloat(String key) {
        String value = this.properties.getProperty(key);
        return Float.parseFloat(value.trim());
    }

    public float getFloat(String key, Float defaultValue) {
        String value = this.properties.getProperty(key);
        return value != null ? Float.parseFloat(value.trim()) : defaultValue;
    }

}
