package com.sgcc.nyyy.process.vo;

public class DeviceStaticProperties {

    //站点ID
    String stationId;

    //额定数据
    String ratedPower;


}
