package com.sgcc.nyyy.process.job.aggregation;

import com.sgcc.nyyy.process.config.GlobalProperties;
import com.sgcc.nyyy.process.entity.DeviceInfo;
import com.sgcc.nyyy.process.job.aggregation.sink.RestClientFactoryImpl;
import com.sgcc.nyyy.process.service.DeviceAggregationService;
import com.sgcc.nyyy.process.service.impl.DeviceAggregationServiceImpl2;
import com.sgcc.nyyy.process.sink.es.ElasticSinkBuilder;
import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.vo.DeviceAggregation;
import com.sgcc.nyyy.process.entity.DevicePower;
import com.sgcc.nyyy.process.vo.DevicePowerData;
import com.sun.xml.internal.ws.developer.Serialization;
import lombok.extern.slf4j.Slf4j;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.apache.flink.util.OutputTag;
import org.elasticsearch.action.ActionRequest;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiFunction;


@Slf4j
public class MinuteDevicePowerAggregation {


    public MinuteDevicePowerAggregation() {


    }

    static DeviceAggregationService service = new DeviceAggregationServiceImpl2();

    //窗口大小
    int windowSize;

    //延迟等待时间
    long lagTime;

    //完成数据聚合
    public void aggregation(SingleOutputStreamOperator<DeviceAggregation> daStream, int windowSize, long lagTime) throws IOException {

        this.windowSize = windowSize;

        this.lagTime = lagTime;

        //按照DeviceCodeHash做分片
        WindowedStream<DeviceAggregation, Integer, TimeWindow> windowedStream = daStream.keyBy(da -> da.getDeviceCode().hashCode() % GlobalProperties.get().getFLINK_TASK_AGGREGATION_SHARD())
                .window(TumblingEventTimeWindows.of(Time.seconds(windowSize)));

        //获取结果数据
        SingleOutputStreamOperator<ArrayList<DevicePowerData>> aggregateStream = aggregateStream(windowedStream);


        //数据持久化
//        addSink(aggregateStream);

        //开启过期监听
//        checkOutDateData(windowedStream, windowSize, lagTime);
    }

    //获取聚合数据
    private SingleOutputStreamOperator<ArrayList<DevicePowerData>> aggregateStream(WindowedStream<DeviceAggregation, Integer, TimeWindow> windowedStream) {
        //将一分钟数据进行聚合，如果有充电枪数据，则将两者数据加总，
        //目前做成了叠加，方便判断计算问题
        SingleOutputStreamOperator<ArrayList<DevicePowerData>> aggregate = windowedStream.aggregate(new AggregateFunction<DeviceAggregation, Map<String, DevicePowerCollector>, ArrayList<DevicePower>>() {

            @Override
            public Map<String, DevicePowerCollector> createAccumulator() {
                return new ConcurrentHashMap<>();
            }

            @Override
            public Map<String, DevicePowerCollector> add(DeviceAggregation da, Map<String, DevicePowerCollector> map) {

                log.debug("2:{}", da.getData().getTs());

                DevicePowerCollector dc = map.get(da.getDeviceCode());
                if (dc == null) {
                    dc = new DevicePowerCollector();
                    map.put(da.getDeviceCode(), dc);
                }
                dc.put(da.getData());
                return map;
            }

            @Override
            public ArrayList<DevicePower> getResult(Map<String, DevicePowerCollector> map) {
                ArrayList<DevicePower> list = new ArrayList<>();
                for (DevicePowerCollector dc : map.values()) {
                    list.add(dc.aggregation());

                    log.error("设备聚合：聚合完毕:{}", dc.getMap());
                }
                return list;
            }

            @Override
            public Map<String, DevicePowerCollector> merge(Map<String, DevicePowerCollector> map1, Map<String, DevicePowerCollector> map2) {
                return AggregationUtil.mergeMap(map1, map2, (collector, collector2) -> DevicePowerCollector.merge(collector, collector2));
            }
        }).map((MapFunction<ArrayList<DevicePower>, ArrayList<DevicePowerData>>) devicePowers -> {
            //进行静态数据获取
            log.error("设备聚合：聚合静态数据");
            //获取所有设备id
            List<String> ids = new ArrayList<>();
            for (DevicePower dp : devicePowers) {
                ids.add(dp.getCode());
            }

            //进行动静态数据汇聚
            ArrayList<DevicePowerData> result = new ArrayList<>();
            if (devicePowers.size() > 0) {
                //根据动态数据id批量获取静态数据信息
                Map<String, DeviceInfo> map = service.getDeviceInfoByDeviceIds(ids);

                log.error("设备聚合：静态数据查询完毕: {}", map.toString());
                for (DevicePower dp : devicePowers) {
                    result.add(DevicePowerData.mergeData(dp, map.get(dp.getCode()), DevicePowerData.DATA_TIME_TYPE_ONE));
                }
            }
            log.error("设备聚合：完成数据转换:{}", result);
            return result;
        }).returns(TypeInformation.of(new TypeHint<ArrayList<DevicePowerData>>() {
        }));

        return aggregate;
    }

    //保存数据
    private void addSink(SingleOutputStreamOperator<ArrayList<DevicePowerData>> aggregateStream) throws MalformedURLException {
        //数据持久化
        if (GlobalProperties.get().isFLINK_TASK_SINK_ENABLE()) {

            log.error("设备聚合：存储数据库");
            ElasticsearchSink<ArrayList<DevicePowerData>> sink = new ElasticSinkBuilder<>(GlobalProperties.get().getES_LOCAL_HOSTS(), new RestClientFactoryImpl(), handler).build(GlobalProperties.get().getElasticSinkConfig());
            aggregateStream.addSink(sink);
        }

    }

    private SingleOutputStreamOperator<ArrayList<DeviceAggregation>> checkOutDateData(WindowedStream<DeviceAggregation, Integer, TimeWindow> windowedStream, int windowSize, long lagTime) {

        SingleOutputStreamOperator<ArrayList<DeviceAggregation>> aggregate = windowedStream.aggregate(new AggregateFunction<DeviceAggregation, ArrayList<DeviceAggregation>, ArrayList<DeviceAggregation>>() {

            @Override
            public ArrayList<DeviceAggregation> createAccumulator() {
                return new ArrayList<>();
            }

            @Override
            public ArrayList<DeviceAggregation> add(DeviceAggregation deviceAggregation, ArrayList<DeviceAggregation> deviceAggregations) {

                //获取该数据的时点值
                if (AggregationUtil.isOutDated(deviceAggregation.getData().getTs(), windowSize, lagTime)) {
                    deviceAggregations.add(deviceAggregation);
                }
                return deviceAggregations;
            }

            @Override
            public ArrayList<DeviceAggregation> getResult(ArrayList<DeviceAggregation> deviceAggregations) {
                return deviceAggregations;
            }

            @Override
            public ArrayList<DeviceAggregation> merge(ArrayList<DeviceAggregation> deviceAggregations, ArrayList<DeviceAggregation> acc1) {
                deviceAggregations.addAll(acc1);
                return deviceAggregations;
            }
        }).returns(TypeInformation.of(new TypeHint<ArrayList<DeviceAggregation>>() {
        })).map(new MapFunction<ArrayList<DeviceAggregation>, ArrayList<DeviceAggregation>>() {
            @Override
            public ArrayList<DeviceAggregation> map(ArrayList<DeviceAggregation> deviceAggregations) throws Exception {
                log.error("设备聚合:过期数据：{}", deviceAggregations);
                return deviceAggregations;
            }
        });

        return aggregate;
    }


    private static DevicePowerElasticHandler handler = new DevicePowerElasticHandler();


    @Serialization
    private static class DevicePowerElasticHandler implements ElasticSinkBuilder.ElasticStoreHandler<ArrayList<DevicePowerData>> {
        @Override
        public String storeIndex(ArrayList<DevicePowerData> devicePower, RuntimeContext runtimeContext) {
//
//            log.error("timestamp:{}", DateUtil.format(runtimeContext.timestamp()));
//            log.error("processingTime:{}", DateUtil.format(runtimeContext.currentProcessingTime()));
//            log.error("watermark:{}", DateUtil.format(runtimeContext.currentWatermark() + 1));
//            log.error("addSink {}", devicePower.toString());
            return "ecp_device_data";
        }

        @Override
        public void onFailure(ActionRequest actionRequest, Throwable throwable, int restStatusCode, RequestIndexer requestIndexer) {

            log.error(throwable.getMessage());
        }

        @Override
        public boolean onFailureThrowException(Throwable throwable) {
            return false;
        }

    }


}
