package com.sgcc.nyyy.process.job;

import org.apache.flink.api.common.ExecutionConfig;
import org.apache.flink.streaming.api.TimeCharacteristic;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.CheckpointConfig;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.source.SourceFunction;

public abstract class BaseFlinkJob<T> {


    private StreamExecutionEnvironment env;

    private DataStream<T> ds;

    private String name;

    public BaseFlinkJob(String name) {
        this.name = name;
        init();
    }

    private void init() {
        this.env = StreamExecutionEnvironment.getExecutionEnvironment();
        initEnvironment(this.env);
    }

    //初始化自定义环境变量
    protected void initEnvironment(StreamExecutionEnvironment env) {
//        env.enableCheckpointing( 1000);
//        env.getCheckpointConfig().setCheckpointTimeout(60000);
//        env.getCheckpointConfig().setFailOnCheckpointingErrors(true);
        env.setStreamTimeCharacteristic(TimeCharacteristic.EventTime);
        env.getConfig().setAutoWatermarkInterval(100l);
    }

    DataStream<T> initDateSource(SourceFunction<T> sf, int parallelism) {
        if (ds == null)
            ds = env.addSource(sf).setParallelism(parallelism <= 0 ? 1 : parallelism);
        return ds;

    }


    /**
     * @return 制定数据源
     */
    protected abstract SourceFunction<T> getSourceFunction();


    /**
     * @param ds 设计数据流过程
     */
    protected abstract boolean process(DataStream<T> ds);


    protected void execute(int parallelism) throws Exception {

        if (process(initDateSource(getSourceFunction(), parallelism))) {
            if (ds == null)
                throw new RuntimeException("需要调用使用initDateStream初始化数据源");

            env.execute(this.name);
        } else {
            throw new RuntimeException("process返回失败");
        }
    }

    protected void close() throws Exception {

    }


}
