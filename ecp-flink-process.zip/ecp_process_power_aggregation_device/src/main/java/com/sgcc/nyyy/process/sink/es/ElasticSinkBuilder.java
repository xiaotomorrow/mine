package com.sgcc.nyyy.process.sink.es;

import com.alibaba.fastjson.JSON;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.streaming.connectors.elasticsearch.ElasticsearchSinkFunction;
import org.apache.flink.streaming.connectors.elasticsearch.RequestIndexer;
import org.apache.flink.streaming.connectors.elasticsearch7.ElasticsearchSink;
import org.apache.flink.streaming.connectors.elasticsearch7.RestClientFactory;
import org.apache.http.HttpHost;
import org.elasticsearch.action.ActionRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.Requests;
import org.elasticsearch.common.xcontent.XContentType;

import java.io.Serializable;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

public class ElasticSinkBuilder<T> extends ElasticsearchSink.Builder<T> {


    /**
     * @param hosts             es的hosts 用逗号分割
     * @param restClientFactory
     * @param handler
     * @throws MalformedURLException
     */
    public ElasticSinkBuilder(String hosts, RestClientFactory restClientFactory, ElasticStoreHandler<T> handler) throws MalformedURLException {
        super(getEsAddresses(hosts), (ElasticsearchSinkFunction<T>) (t, runtimeContext, requestIndexer) -> {

            if (handler != null) {
                //这里默认做单元素的增加

                List<T> list = new ArrayList<>();
                if (t instanceof Iterable) {
                    ((Iterable<?>) t).forEach(a -> {
                        list.add((T) a);
                    });
                } else {
                    list.add(t);
                }

                for (T item : list) {
                    IndexRequest request = Requests.indexRequest().index(handler.storeIndex(t, runtimeContext)).source(JSON.toJSONString(item), XContentType.JSON);
                    requestIndexer.add(request);
                }

            }

        });
        this.setFailureHandler((actionRequest, failure, restStatusCode, requestIndexer) -> {

                    if (handler != null) {
                        handler.onFailure(actionRequest, failure, restStatusCode, requestIndexer);
                    }

                    if (handler != null) {
                        if (handler.onFailureThrowException(failure))
                            throw failure;
                    }
                }
        );

        //设置restClient
        if (restClientFactory != null) {
            setRestClientFactory(restClientFactory);
        }
    }


    /**
     * @param config 批处理与重试配置
     */
    public void setConfig(ElasticSinkConfig config) {

        if (config != null) {

            if (config.getBulkFlushInterval() > 0)
                setBulkFlushInterval(config.getBulkFlushInterval());

            if (config.getBulkFlushMaxActions() > 0)
                setBulkFlushMaxActions(config.getBulkFlushMaxActions());

            if (config.getBulkFlushMaxSizeMb() > 0)
                setBulkFlushMaxSizeMb(config.getBulkFlushMaxSizeMb());

            if (config.isBulkFlushBackoff()) {

                setBulkFlushBackoff(config.isBulkFlushBackoff());

                setBulkFlushBackoffRetries(config.getBulkFlushBackoffRetries());

                setBulkFlushBackoffDelay(config.getBulkFlushBackoffDelay());

                setBulkFlushBackoffType(config.getFlushBackoffType());
            }
        }
    }

    public interface ElasticStoreHandler<T> extends Serializable {

        /**
         * 返回数据对应存储的index
         */
        String storeIndex(T t, RuntimeContext runtimeContext);


        /**
         * 失败处理
         *
         * @param actionRequest
         * @param throwable
         * @param restStatusCode
         * @param requestIndexer
         */
        void onFailure(ActionRequest actionRequest, Throwable throwable, int restStatusCode, RequestIndexer requestIndexer);

        /**
         * 根据失败原因判断是否需要继续抛出异常
         *
         * @param throwable
         * @return
         */
        boolean onFailureThrowException(Throwable throwable);

    }


    /**
     * 解析配置文件的 es hosts
     *
     * @param hosts
     * @return
     * @throws
     */
    public static List<HttpHost> getEsAddresses(String hosts) throws MalformedURLException {
        String[] hostList = hosts.split(",");
        List<HttpHost> addresses = new ArrayList<>();
        for (String host : hostList) {
            if (host.startsWith("http")) {
                URL url = new URL(host);
                addresses.add(new HttpHost(url.getHost(), url.getPort()));
            } else {
                String[] parts = host.split(":", 2);
                if (parts.length > 1) {
                    addresses.add(new HttpHost(parts[0], Integer.parseInt(parts[1])));
                } else {
                    throw new MalformedURLException("invalid elasticsearch hosts format");
                }
            }
        }
        return addresses;
    }

    public ElasticsearchSink<T> build(ElasticSinkConfig config) {
        //设置配置文件
        setConfig(config);
        return super.build();
    }
}
