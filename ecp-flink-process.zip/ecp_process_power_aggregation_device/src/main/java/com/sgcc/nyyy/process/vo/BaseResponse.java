package com.sgcc.nyyy.process.vo;

import java.util.Calendar;


/**
 * 返回数据格式
 *
 * @param <T>
 */
public class BaseResponse<T> {


    /**
     * 200 成功，否则表示失败
     */
    private int resultCode = 200;

    /**
     * 结果描述/消息
     */
    private String msg = "ok";

    /**
     * 當前時間戳
     */
    private Long timestamp = Calendar.getInstance().getTimeInMillis();
    /**
     * 返回的数据
     */
    private T data;


    public BaseResponse() {
    }

    public int getResultCode() {
        return resultCode;
    }

    public void setResultCode(int resultCode) {
        this.resultCode = resultCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Long timestamp) {
        this.timestamp = timestamp;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }
}
