package com.sgcc.nyyy.process.sf.simulate;

import lombok.extern.slf4j.Slf4j;
import org.apache.flink.streaming.api.functions.source.RichSourceFunction;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public abstract class SimulateSourceFunction<T> extends RichSourceFunction<T> {

    private boolean isRunning = false;

    private static final long BATCH_PERIOD = 1000l;

    private int threadNumber;

    protected long interval;


    public SimulateSourceFunction(int threadNumber, long interval) {
        this.threadNumber = threadNumber;
        this.interval = interval;
    }

    protected abstract T simulate();

    List<SimulateThread> threads = new ArrayList<>();


    @Override
    public void run(SourceContext<T> sourceContext) throws Exception {

        if (!isRunning) {
            isRunning = true;

            for (int i = 0; i < this.threadNumber; i++) {
                SimulateThread t = new SimulateThread(sourceContext, this.interval);
                t.setName("SimulateSourceFunction" + i);
                threads.add(t);
                t.start();
                Thread.sleep(100);
            }
        }
        while (isRunning) {
            Thread.sleep(BATCH_PERIOD);
        }

    }

    @Override
    public void cancel() {
        log.error("source function cancel");
        this.isRunning = false;
        for (SimulateThread thread : threads) {
            thread.doStop();
        }
        threads.clear();
    }

    @Override
    public void close() throws Exception {

        log.error("source function close");
        super.close();
        this.isRunning = false;
        for (SimulateThread thread : threads) {
            thread.doStop();
        }
        threads.clear();
    }

    /**
     * 模拟线程
     */
    private class SimulateThread extends Thread {
        private SourceContext<T> sourceContext;
        private boolean running = false;
        private long interval;

        public SimulateThread(SourceContext<T> sourceContext, long interval) {
            this.sourceContext = sourceContext;
            this.interval = interval;
        }


        @Override
        public void run() {
            log.info("{}  is started", Thread.currentThread().getName());
            running = true;
            while (running) {
                //生成模拟数据
                T sumulateObj = simulate();
                //模拟发送数据至flink
                this.sourceContext.collect(sumulateObj);
                log.info("{} is emitted ", sumulateObj.toString());
                try {
                    Thread.sleep(this.interval);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            log.info("{}  is stopped", Thread.currentThread().getName());
        }

        protected void doStop() {
            running = false;
        }
    }


}
