package com.sgcc.nyyy.process.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@ToString
@Getter
@Setter
@NoArgsConstructor
public class UnitPower {
    public static final int DATA_TIME_TYPE_ONE = 1;

    public static final int DATA_TIME_TYPE_FIVE = 2;

    public static final int DATA_TIME_TYPE_FIFTEEN = 3;

    //聚合单元编码
    private String code;


    private Integer dataTimeType; //数据类型，1：1分钟 2：5分钟 3：15分钟

    //功率kw
    private float power;

    //时间，将决定该数据属于哪个时间窗口，需要谨慎设置
    private long ts;

    //总额定功率
    private float ratedPower;

    //总额定功率
    private float minPower;

    //在线设备数
    private int onlineDevice;
}
