package com.sgcc.nyyy.process.job.aggregation.sink;

import com.sgcc.nyyy.process.config.GlobalProperties;
import org.apache.flink.streaming.connectors.elasticsearch7.RestClientFactory;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClientBuilder;

/***
 * ES https 配置
 */
public class RestClientFactoryImpl implements RestClientFactory {

    private static volatile RestClientFactoryImpl instance = null;
    /**
     * 初始化
     * 单例模式
     * @return
     */
    public static RestClientFactoryImpl getInstance() {
        if (instance == null) {
            synchronized (instance) {
                instance = new RestClientFactoryImpl();
            }
        }
        return instance;
    }

    @Override
    public void configureRestClientBuilder(RestClientBuilder restClientBuilder) {

        final CredentialsProvider credentialsProvider = new BasicCredentialsProvider();
        credentialsProvider.setCredentials(AuthScope.ANY,
                new UsernamePasswordCredentials(GlobalProperties.get().getES_USER(), GlobalProperties.get().getES_PASSWORD()));

        restClientBuilder.setHttpClientConfigCallback(new RestClientBuilder.HttpClientConfigCallback() {//设置自定义http客户端配置
            @Override
            public HttpAsyncClientBuilder customizeHttpClient(HttpAsyncClientBuilder httpClientBuilder) {
                httpClientBuilder.disableAuthCaching();
                return httpClientBuilder.setDefaultCredentialsProvider(credentialsProvider);
            }

        });

    }


}