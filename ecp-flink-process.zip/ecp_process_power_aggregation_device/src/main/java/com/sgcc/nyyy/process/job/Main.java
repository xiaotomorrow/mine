package com.sgcc.nyyy.process.job;

import com.sgcc.nyyy.process.job.aggregation.MinuteAggregationJob;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Main {

    public static void main(String[] args) throws Exception {
        //开启分钟级数据汇聚
        MinuteAggregationJob minuteAggregationJob = new MinuteAggregationJob();
        minuteAggregationJob.execute(1);

    }
}
