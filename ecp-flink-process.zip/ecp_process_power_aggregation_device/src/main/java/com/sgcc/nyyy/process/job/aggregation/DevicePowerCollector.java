package com.sgcc.nyyy.process.job.aggregation;

import com.aliyun.openservices.shade.io.netty.util.internal.StringUtil;
import com.sgcc.nyyy.process.utils.AggregationUtil;
import com.sgcc.nyyy.process.utils.DateUtil;
import com.sgcc.nyyy.process.entity.DevicePower;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Data
public class DevicePowerCollector {

    private Map<String, DevicePower> map = new ConcurrentHashMap<>();


    private String deviceCode;

    //站点或者聚合单元的code
    private String relativeCode;

    public DevicePowerCollector() {
    }

    public void put(DevicePower dp) {
        log.debug("1:{}", dp.getTs());
        synchronized (this) {
            if (StringUtil.isNullOrEmpty(this.deviceCode)) {
                this.deviceCode = dp.getCode();
            }
            //获取枪ID
            String key = dp.getSubCode();

            //TODO： 是否考虑加总和总功率的比较

            if (map.containsKey(key)) {
                DevicePower dp_old = map.get(key);
                dp_old.setPower(dp_old.getPower() + dp.getPower());
//                    dp_result = DevicePower.compare(dp_result,dp_old);
                log.debug("map {},{}, size：{}", DateUtil.format(AggregationUtil.getDevicestampOfWatermark(dp.getTs(), 20)), dp.getTs(), dp_old.getPower());
            } else {
                map.put(key, dp);
            }
        }
    }


    public DevicePower aggregation() {
        String code = "";
        float power = 0.0f;
        long ts = 0l;
        for (DevicePower dp : map.values()) {
            power += dp.getPower();
            code = dp.getCode();
            ts = Math.max(dp.getTs(), ts);
        }

        DevicePower result = new DevicePower();
        result.setCode(code);
        result.setPower(power);
        result.setTs(ts);
        return result;
    }


    /**
     * 将2个DevicePowerCollector进行聚合
     *
     * @param dc1
     * @param dc2
     * @return
     */
    public static DevicePowerCollector merge(DevicePowerCollector dc1, DevicePowerCollector dc2) {

        DevicePowerCollector dc = new DevicePowerCollector();
        String code = dc1.getDeviceCode();
        Map<String, DevicePower> map = AggregationUtil.mergeMap(dc1.getMap(), dc2.getMap(), (a, b) -> {
            DevicePower dp = new DevicePower();
            dp.setPower(a.getPower() + b.getPower());
            dp.setCode(a.getCode());
            dp.setTs(Math.max(a.getTs(), b.getTs()));
            return dp;
        });
        dc.setMap(map);
        dc.setDeviceCode(code);
        dc.setRelativeCode(dc1.getRelativeCode());
        return dc;
    }


}
