package com.sgcc.nyyy.process.utils;

import com.sgcc.nyyy.process.config.GlobalProperties;
import feign.Feign;
import feign.Request;

/***
 * Feign 工具类
 */
public class FeignUtils{


    public static volatile Feign.Builder builder = null;

    public static Feign.Builder getInstance(){
        if (builder==null){
            synchronized (FeignUtils.class) {
                GlobalProperties globalProperties = GlobalProperties.get();
                // 超时配置
                Request.Options options = new Request.Options(globalProperties.getECP_CONNECT_TIMEOUT_MILLIS(),globalProperties.getECP_READ_TIMEOUT_MILLIS());
                builder = Feign.builder().options(options);
            }
        }
        return builder;
    }

}
